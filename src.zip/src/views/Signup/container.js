import { connect } from 'react-redux'
import SignupComponent from './component'

const SignupContainer = connect(
  // Map state to props
  state => ({
   
  }),
  // Map actions to dispatch and props
  {
  }
)(SignupComponent)

export default SignupContainer
